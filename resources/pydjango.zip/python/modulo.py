#!/usr/bin/env python

"""
Este modulo tem como funcao exemplificar o uso dos atributos
__name__, __file__ e __doc__ de um modulo.
"""

print __name__

if __name__ == "__main__":
    print __name__
    print "Executando modulo..."
