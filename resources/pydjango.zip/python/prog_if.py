a = input("A:")
b = input("B:")

if a > b:
    print "A é maior que B"
elif b > a:
    print "B é maior que A"
else:
    print "A e B são iguais"
