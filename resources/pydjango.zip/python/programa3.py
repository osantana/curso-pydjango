#!/usr/bin/env python
# -*- coding: utf-8 -*-
# programa3.py – Exemplo com comentários
print # imprime uma linha em branco

# Imprime outra linha em branco
print

if valor != "ola":
    print valor
# comando de debug
    print "DEBUG"
    """
    Comentários com mais de uma linha
    precisam ficar dentro de uma
    string multilinha.
    """
